# SteadyVoice 1.4.0 quick start

Extract **SteadyVoice-1.4.0-Windows-x64.zip**. Close audio applications and unload
the previous plugin before replacing `SteadyVoice.dll`, then restart them.

1. In 64-bit OBS, copy the DLL to `C:\Program Files\Common Files\VST2\`.
   Add **VST 2.x Plug-in** to the microphone filters, select SteadyVoice,
   and open its interface. In 64-bit Equalizer APO, add a VST plugin filter
   and browse to the DLL. Use one active instance in the microphone path.
2. Select **Smooth boost**. It starts at Target **−16 dBFS RMS**, Maximum boost
   **24 dB**, Maximum cut **40 dB**, Lift **150 ms**, Reduce **20 ms**,
   Peak ceiling **−1 dBFS**, Guard **On**, Adaptive RMS **On**, and
   Lookahead **5 ms**. Keep Output trim at 0 dB and Bypass Off.
3. Set Noise floor above room noise and below soft speech. The preset starts
   at −50 dBFS with a 600 ms pause hold. Record quiet speech immediately
   followed by a loud phrase, normal speech, and a pause.
4. Use **RMS / Lookahead** to adjust the five detector durations. Defaults
   are **200 / 120 / 80 / 24 / 8 ms** for Softest / Soft / Median / Loud /
   Loudest. Longer durations stabilize detection; shorter durations respond
   faster. Lift and Reduce still control gain smoothing separately.
5. Adjust Lookahead while paused: changing it flushes buffered audio and can
   briefly interrupt output. Compare plugin output and the final recording.
   Lower Target if the guard is working frequently; increase boost only as
   much as quiet speech needs.

**Median range** is a full-width target-centered input band, default **6 dB**.
At Target −16 dBFS it covers −19 to −13 dBFS. Soft/Softest sit 12/24 dB
below the lower edge. Upper spacing is the smaller of 12 dB or half the
distance from the upper edge to 0 dBFS: Loud is −6.5 dBFS and Loudest is
0 dBFS here. If the band already includes 0 dBFS, upper anchors fall back
to 12/24 dB beyond its upper edge. The editor displays the actual anchors.
An independent 12 ms full-band detector selects the range; continuously
active envelopes blend between anchors. This range does not disable gain
correction. RMS controls are exponential detector time constants, not exact
windows or audio delays.

**Lookahead** is 0–20 ms of added audio delay; at 48 kHz, 5 ms means 240
samples. It anticipates the peak guard, with a linear attack before overloads,
10 ms cap hold, and 80 ms release. Main leveling remains causal.
Processed audio and bypass share the delay, including with Guard Off. The
plugin reports delay changes to the host; a host that does not update its
compensation may need its audio pipeline restarted. Compensation does not
remove live microphone delay.

**Target and peaks:** −8 dBFS RMS speech with a 12 dB crest factor would need
+4 dBFS peaks. Raising maximum boost cannot make that fit below full scale.
The original guard already reduces samples before plugin output; persistent
limiting or 4 ms gain smoothing can still alter the sound. Lookahead helps
anticipate peaks, but does not make an excessive RMS target achievable.
Guard On protects the sample ceiling only with Bypass fully Off. It does not
repair upstream distortion or guarantee inter-sample/encoded peaks. Put a
final limiter after later gain or mixing when required.

**Existing settings:** the original four presets retain their values with
Adaptive RMS Off and Lookahead 0 ms, matching the original causal path.
Actual version-1–3 saved chunks migrate with physical values preserved and
new controls at defaults. New saves use version 4 and require this update.
The original thirteen parameter indices and 1.3.0 mappings remain unchanged;
eight controls are appended. Check historical range changes if restoring raw
normalized settings or automation from 1.0.0/1.1.0.

**Validation:** Linux DSP, loud-response, adaptive/lookahead, and actual-plugin
host suites pass. See `docs/VALIDATION.md` for Windows build/editor results and
testing limits. No user audio was supplied; synthetic success does not
establish that the reported audible issue has been resolved. The package
includes source, documentation, licenses, and a synthetic Windows test host.

OBS scan locations: https://obsproject.com/kb/vst-2-x-plugin-filter
