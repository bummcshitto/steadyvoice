# SteadyVoice 1.4.0 validation

Validation date: 9 October 2026 (Asia/Manila).

The delivered DLL was rebuilt from the included source with GCC 14.2 MinGW-w64
(POSIX x86-64) and binutils 2.44. Compiler runtimes are statically linked.
The PE is Windows x64, exports `VSTPluginMain`, and imports only GDI32,
KERNEL32, msvcrt, and USER32. Plugin and resource versions identify 1.4.0;
the original plugin ID is preserved.

DLL SHA-256: `5edd896a9f8de2f44d4592d80ab95dddd0ca9355bbd3e6be1adfd1f12f659e3b`.

## Completed checks

| Check | Result |
| --- | --- |
| CMake build / CTest | All four registered suites passed. |
| Original DSP suite | 158 assertions passed. Gain caps, silence, zero times, stereo, guard, corruption, distortion, and block independence. |
| Adaptive RMS / lookahead | 1,207 assertions passed. Bands, interpolation, quiet gain, peak overloads, exact delay, bypass, float/double, in-place, stereo, parameter changes, startup, and pause recovery. |
| Loud-response regressions | 46 assertions passed. Full-band detection, loud catch, guard handoff/toggles, settings/rate combinations, and the test-only 1.2.0 comparison. This verifies the retained zero-lookahead path. |
| Linux actual-plugin host | 54,235 assertions passed. ABI, parameters, fifth preset, strict v4 state and real 68-byte v1–v3 migration, malformed state, delay notifications, exact wet/bypass latency, concurrency, and allocation-free callbacks. |
| Windows actual DLL + native editor | 54,375 assertions passed under Wine 10 / Xvfb. Both tabs, typed values, fractional lookahead, host delay updates, switches, keyboard navigation, reopening, and all saved controls. |
| AddressSanitizer / UndefinedBehaviorSanitizer | DSP, adaptive/lookahead, and instrumented actual-plugin host passed with float divide-by-zero checking. LeakSanitizer was disabled; these runs do not establish leak freedom. |

Latency and guard tests cover rates from 8 kHz through 384 kHz. Output is
identical across host block sizes of 1 and 511 samples. The bypass impulse is
exactly delayed by the reported sample count, including with Guard Off.
Audio callbacks and sample-rate/parameter reconfiguration allocate no C++ heap
memory in the instrumented Linux host. Lookahead storage is fixed per instance.

The Windows runtime tests load the actual delivered PE DLL, rather than a
Linux substitute. They are compatibility tests under Wine, not a run in OBS
or Equalizer APO on a physical Windows audio device. Wine reports zero for
`GetGuiResources`, so actual Windows GDI leak counts remain unverified.

## Audio measurements

With Smooth boost and a stressed alternating quiet/loud fixture:

- Protected sample peak: **−1.000 dBFS**.
- Sustained soft-passage gain: **22.005 dB**.
- A separate very-soft fixture received its full **24.000 dB** boost cap.
- The first loud-passage RMS was **−11.268 dBFS**; it remained audible.
- Turning Guard Off made the overload fixture exceed full scale, confirming
  that the protected test actually exercised peak reduction.

An isolated peak test disables primary leveling, uses +12 dB trim, and places
one 0.9-amplitude sample in a 0.1-amplitude signal. The largest adjacent guard
gain step fell as follows. These values characterize this fixture, not all
speech or perceived transparency.

| Lookahead | Largest guard gain step |
| ---: | ---: |
| 0 ms | 12.084850 dB |
| 5 ms | 0.144290 dB |
| 20 ms | 0.036298 dB |

The delayed guard begins reducing gain before that peak reaches the output.
A settled coherent 1 kHz float tone held its −1 dBFS sample peak with THD
approximately **−149.54 dB** for 0, 5, and 20 ms. Tests also require the
settled level to reach the ceiling: silence or excess attenuation cannot pass
merely by producing low distortion. A cold-start overload must reach the
proper protected level on the first actual delayed sample.

Sub-ceiling audio with leveling disabled passes bit-exactly apart from the
specified delay. With Guard Off, lookahead delays the causal leveled signal;
it does not anticipate the primary RMS controller. Changing Lookahead flushes
queued audio, so it is intended to be adjusted while paused.

At Smooth boost's target −16 dBFS and median width 6 dB, classifier anchors are
Softest −43, Soft −31, Median −19 to −13, Loud −6.5, and Loudest 0 dBFS.
The independent full-band classifier selects continuously active envelopes;
blend boundaries are continuous. The geometric duration diagnostic is an
interpolation label, not an exact integration window for the blended powers.

## Reproduce

From the included source directory:

```sh
bash tools/test-linux.sh
bash tools/build-mingw.sh
```

On Windows, run the packaged `tools/ValidatePlugin.bat` for synthetic audio and
native editor checks. It does not access a microphone. A screenshot file can
also be supplied to the standalone host:

```bat
tools\ValidatePlugin.exe SteadyVoice.dll main.bmp advanced.bmp
```

See BUILD.md for CMake and sanitizer recipes. Logs are included beside this
record; factory editor screenshots are in `images/`.

## Practical limits

No recording of the user's reported problem was supplied. These synthetic
results demonstrate numerical behavior and smoother guard attack; they do not
establish the user's perceived muffling is resolved or localize clipping in
the user's signal chain.

A −8 dBFS RMS target plus a 12 dB crest factor requires +4 dBFS peaks. Adaptive
timing and lookahead cannot retain both that average and unclipped peaks below
full scale without changing the signal's dynamics. Guard protection is a
sample ceiling with full processing engaged, not true-peak, upstream repair,
or downstream mixing/encoding protection. Bypass and its crossfade include dry
audio. Longer RMS durations still delay level estimates: the new lookahead
anticipates peak guarding while the main leveling gain remains causal.
