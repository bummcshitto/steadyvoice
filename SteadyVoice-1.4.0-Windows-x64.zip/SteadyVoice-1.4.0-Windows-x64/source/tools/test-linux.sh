#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
sv_cxx="${SV_CXX:-g++}"
mkdir -p build
"$sv_cxx" -std=c++17 -O3 -Wall -Wextra -Wpedantic \
  tests/dsp_tests.cpp -o build/dsp_tests
"$sv_cxx" -std=c++17 -O3 -Wall -Wextra -Wpedantic \
  tests/adaptive_tests.cpp -o build/adaptive_tests
"$sv_cxx" -std=c++17 -O3 -Wall -Wextra -Wpedantic \
  tests/loudness_tests.cpp -o build/loudness_tests
"$sv_cxx" -std=c++17 -O3 -Wall -Wextra -Wpedantic -fno-math-errno \
  -shared -fPIC -fvisibility=hidden src/plugin.cpp src/editor.cpp \
  -o build/SteadyVoice.so
"$sv_cxx" -std=c++17 -O3 -Wall -Wextra -Wpedantic -rdynamic \
  tests/host_tests.cpp -o build/host_tests -ldl -pthread
build/dsp_tests
build/adaptive_tests
build/loudness_tests
build/host_tests "$PWD/build/SteadyVoice.so"
